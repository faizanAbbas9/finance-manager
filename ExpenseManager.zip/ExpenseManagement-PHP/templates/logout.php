<?php
    include_once "../init.php";
    $getFromU->logout();
?>